clc
close all
clear all
cd('/Users/pariasamimi/Documents/PhD/Sainty check/ECG_paria_test')
%% reconstracted ECG signal from the function generator
reconstracted=readtable("25-03-2021_15-16-24_ecg5.csv");
reconstracted=table2array(reconstracted);
RE=reconstracted';
reconstracted=RE((2:25),:);
for i=1:24
reconstracted(i,:) = reconstracted(i,:)/ sqrt( sum( reconstracted(1,:).^2 ) );
reconstracted(i,:) = reconstracted(i,:) * sqrt( 3.9811e-6 ) / sqrt( sum( reconstracted(i,:).^2 ) );
end
reconstracted=reconstracted(1,(3000:3500));
% %% original ECG signal
% original = load('original_ECG.mat');
% original=original.mydata;
% for j=1:24
% original(j,:) = original(j,:) / sqrt( sum( original(j,:).^2 ) );
% original(j,:) = original(j,:) * sqrt( 3.9811e-6 ) / sqrt( sum( original(j,:).^2 ) );
% end
% original=original(1,(1:5000));
% plot(original, 'r');
% hold on
plot(reconstracted, 'g');
legend({'reconstracted_ECG signal'});
title ('ECG_comparison')
xlabel('Time(Sec)')
xlabel('Amplitute')
%if =0 mean the two signals are the same
% i=mean((original(:)-reconstracted(:)).^2);