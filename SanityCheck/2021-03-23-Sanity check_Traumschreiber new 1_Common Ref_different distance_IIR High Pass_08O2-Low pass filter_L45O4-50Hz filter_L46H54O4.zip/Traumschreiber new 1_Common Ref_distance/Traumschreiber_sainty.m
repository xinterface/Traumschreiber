close all
clear all

%%
dir_tmp='/Users/pariasamimi/Documents/PhD/Sainty check';
cd(dir_tmp);
A=dir;
for i=1:length(A)-2;
  gg=strcat(dir_tmp,'/',A(i+2).name,'/',A(i+2).name,'_rereferenced_avg.mat');
  load(gg)
a=EEG_Rereferenced_avg(:,:,:);
c=a;
numChannels=size(c,1);

%% filtering
eeglab;

filter_order=80;  % 250/3 %Filter order for Lowpass FIR filter --default is 3*fix(EEG_freq/Low_freq)--
EEG.data=double(c);
EEG.srate=250;    % sampleling frequency 
low=0;
high=40;
eeglab redraw
EEG = pop_eegfilt( EEG, low, 0, filter_order);
EEG = pop_eegfilt( EEG,0, high , filter_order);
eeglab redraw
out=EEG.data;

%% SAVE
save([dir_tmp,'/',A(i+2).name,'/',A(i+2).name '_EEG.mat'],'out');

end